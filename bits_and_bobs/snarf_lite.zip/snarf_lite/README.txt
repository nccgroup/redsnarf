RedSnarf Lite Beta - is a remote connection initiated version of RedSnarf with basic funcionality.

In the py2exe_built folder you will find a compiled exe version of the client which should be run on a windows box
In the py2exe_buildfiles folder you will find everything you need to compile your own version

snarf_server.py should be run from Kali.

