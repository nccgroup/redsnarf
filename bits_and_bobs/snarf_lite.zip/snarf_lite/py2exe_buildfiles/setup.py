#setup.py
from distutils.core import setup
import py2exe

setup(console=['snarf_client.py'])
